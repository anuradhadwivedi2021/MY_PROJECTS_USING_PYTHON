import random

while True:
    input("Press Enter to roll the dice...")
    print("🎲 You rolled:", random.randint(1, 6))
    if input("Roll again? (y/n): ") != "y":
        break
