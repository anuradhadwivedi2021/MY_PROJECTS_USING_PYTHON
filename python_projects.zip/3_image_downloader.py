import requests

url = input("Enter image URL: ")
filename = "downloaded_image.jpg"

r = requests.get(url)
with open(filename, 'wb') as f:
    f.write(r.content)

print("✅ Image downloaded as", filename)
